# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['curses-dom']

package_data = \
{'': ['*']}

install_requires = \
['docopt>=0.6.2,<0.7.0', 'requests>=2.26.0,<3.0.0']

entry_points = \
{'console_scripts': ['curses-dom = curses-dom.main:main']}

setup_kwargs = {
    'name': 'curses-dom',
    'version': '0.1.0',
    'description': 'terminal renderer for html/css',
    'long_description': None,
    'author': 'Kevin Lai',
    'author_email': 'zlnh4@umsystem.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
