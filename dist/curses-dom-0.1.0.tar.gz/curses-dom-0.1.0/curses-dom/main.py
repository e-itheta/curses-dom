"""Usage: curses-dom [ <uri> ]"""
import curses
import docopt
import asyncio

from urllib.parse import urlparse
from . import curses_util



def main():
    args = docopt.docopt(__doc__)
    loop = asyncio.get_event_loop()
    render_queue = asyncio.Queue()

    if args["<uri>"] is not None:
        from . import url_util
         


    
    @curses.wrapper
    def _main(stdscr: curses.window):
        stdscr.nodelay(1)
        
        curses_util.init_event_listener(
            stdscr.getch,
            [ lambda ev: stdscr.addstr(chr(ev)) ]
        )

        loop.run_forever()
    
        
        

        

        
    